#include "../../include/views/GameUI.hpp"

#include "../../include/utils/GameException.hpp"
#include "../../include/views/AnsiTheme.hpp"

#include <algorithm>
#include <cctype>
#include <iostream>
#include <string>
#include <vector>

GameUI::GameUI(GameEngine& engine)
    : engine(engine),
      started(false) {}

void GameUI::displayWelcome() const {
    std::cout << AnsiTheme::clearScreen();
    std::cout << AnsiTheme::apply(AnsiTheme::bold(), "Nimonspoli CLI - FRP") << "\n";
    std::cout << "Ketik BANTUAN untuk melihat daftar perintah.\n";
    std::cout << "Ketik KELUAR untuk menutup program.\n\n";
}

void GameUI::bootstrapIfNeeded() {
    if (started) {
        return;
    }

    while (!started) {
        std::cout << "Menu awal [NEW/LOAD] (default NEW): ";
        std::string menuChoice;
        std::getline(std::cin, menuChoice);

        std::string normalized = menuChoice;
        std::transform(
            normalized.begin(),
            normalized.end(),
            normalized.begin(),
            [](unsigned char c) { return static_cast<char>(std::toupper(c)); });

        try {
            if (normalized == "LOAD" || normalized == "MUAT") {
                std::cout << "Nama file save (.txt, default file_save.txt): ";
                std::string filename;
                std::getline(std::cin, filename);
                if (filename.empty()) {
                    filename = "file_save.txt";
                }

                CommandResult loadResult = engine.loadGame(filename);
                std::cout << formatter.format(loadResult) << "\n";
                started = true;
                return;
            }

            int nPlayers = 4;
            std::vector<std::string> names;

            std::cout << "Jumlah pemain (2-4, default 4): ";
            std::string rawN;
            std::getline(std::cin, rawN);

            if (!rawN.empty()) {
                try {
                    const int parsed = std::stoi(rawN);
                    if (parsed >= 2 && parsed <= 4) {
                        nPlayers = parsed;
                    }
                } catch (const std::exception&) {
                    // Fallback ke default 4 pemain.
                }
            }

            names.reserve(nPlayers);
            for (int i = 0; i < nPlayers; ++i) {
                std::cout << "Nama pemain " << (i + 1) << ": ";
                std::string name;
                std::getline(std::cin, name);
                if (name.empty()) {
                    name = "P" + std::to_string(i + 1);
                }
                names.push_back(name);
            }

            CommandResult startResult = engine.startNewGame(nPlayers, names);
            std::cout << formatter.format(startResult) << "\n";
            started = true;
        } catch (const GameException& e) {
            std::cout << AnsiTheme::apply(AnsiTheme::error(), "[ERROR] ") << e.what() << "\n";
        } catch (const std::exception& e) {
            std::cout << AnsiTheme::apply(AnsiTheme::error(), "[FATAL] ") << e.what() << "\n";
        }
    }
}

void GameUI::run() {
    displayWelcome();
    bootstrapIfNeeded();

    std::string raw;
    while (true) {
        std::cout << AnsiTheme::apply(AnsiTheme::bold(), "> ");
        if (!std::getline(std::cin, raw)) {
            break;
        }

        try {
            Command cmd = parser.parse(raw);
            if (cmd.type == CommandType::EXIT) {
                std::cout << "Sampai jumpa!\n";
                break;
            }

            CommandResult result = engine.processCommand(cmd);
            std::cout << formatter.format(result) << "\n";

            if (cmd.type == CommandType::PRINT_BOARD) {
                std::cout << renderer.render(
                    engine.getBoard(),
                    engine.getPlayers(),
                    engine.getCurrentTurn(),
                    engine.getMaxTurn())
                          << "\n";
            }
        } catch (const GameException& e) {
            std::cout << AnsiTheme::apply(AnsiTheme::error(), "[ERROR] ") << e.what() << "\n";
        } catch (const std::exception& e) {
            std::cout << AnsiTheme::apply(AnsiTheme::error(), "[FATAL] ") << e.what() << "\n";
        }
    }
}
