#include "../../include/models/TaxTile.hpp"
#include "../../include/core/BankruptcyManager.hpp"
#include "../../include/core/GameEngine.hpp"
#include "../../include/core/TransactionLogger.hpp"
#include "../../include/models/Bank.hpp"
#include "../../include/models/Player.hpp"
#include "../../include/models/Property.hpp"
#include "../../include/models/StreetProperty.hpp"
#include "../../include/utils/GameException.hpp"

#include <iostream>

TaxTile::TaxTile(int index, TaxType taxType, int flatAmount, int percentage) : Tile (index, taxType == TaxType::PPH ? "PPH" : "PBM", taxType == TaxType::PPH ? "Pajak Penghasilan" : "Pajak Barang Mewah"), taxType(taxType), flatAmount(flatAmount), percentage(percentage) {}

TaxType TaxTile::getTaxType() const{
    return taxType;
}

int TaxTile::getFlatAmount() const{
    return flatAmount;
}

int TaxTile::getPercentage() const{
    return percentage;
}

void TaxTile::handlePPH(Player& player, GameEngine& engine){
    if (player.isShieldActive()) {
        std::cout << "[SHIELD ACTIVE]: Tagihan PPH dibatalkan.\n";
        return;
    }

    const int wealth = calculateWealth(player);
    const int taxPct = (wealth * percentage) / 100;
    const int taxFlat = flatAmount;

    int choice = 1;
    if (player.canAfford(taxFlat) && player.canAfford(taxPct)) {
        std::cout << "PPH: pilih metode pembayaran\n";
        std::cout << "1. Flat M" << taxFlat << "\n";
        std::cout << "2. " << percentage << "% dari kekayaan (M" << wealth << ") = M" << taxPct << "\n";
        std::cout << "Pilihan [1/2]: ";
        std::cin >> choice;
        if (choice != 2) choice = 1;
    } else if (!player.canAfford(taxFlat) && player.canAfford(taxPct)) {
        choice = 2;
    } else if (!player.canAfford(taxFlat) && !player.canAfford(taxPct)) {
        choice = (taxFlat <= taxPct) ? 1 : 2;
    }

    const int tax = (choice == 2) ? taxPct : taxFlat;
    if (!player.canAfford(tax)) {
        engine.getBankruptcyManager().handleDebt(player, tax, nullptr);
        return;
    }

    engine.getBank().receivePayment(player, tax);
    engine.getLogger().logTax(player.getUsername(), "PPH", tax);
}

void TaxTile::handlePBM(Player& player, GameEngine& engine){
    if (player.isShieldActive()) {
        std::cout << "[SHIELD ACTIVE]: Tagihan PBM dibatalkan.\n";
        return;
    }

    if (!player.canAfford(flatAmount)) {
        engine.getBankruptcyManager().handleDebt(player, flatAmount, nullptr);
        return;
    }

    engine.getBank().receivePayment(player, flatAmount);
    engine.getLogger().logTax(player.getUsername(), "PBM", flatAmount);
}

int TaxTile::calculateWealth(const Player& player) const{
    int wealth = player.getMoney();

    for (const Property* prop : player.getOwnedProperties()){
        if (!prop) {
            throw GameException("Null property found in owned properties of '"
                + player.getUsername() + "'.");
        }

        wealth += prop->getPurchasePrice();

        if (prop->getType() == PropertyType::STREET){
            const auto* street = static_cast<const StreetProperty*>(prop);
            wealth += street->getBuildingSellValue() * 2;
        }
    }
    return wealth;
}

void TaxTile::onLand(Player& player, GameEngine& engine) {
    if (taxType == TaxType::PPH){
        handlePPH(player, engine);
    }
    else{
        handlePBM(player, engine);
    }
}