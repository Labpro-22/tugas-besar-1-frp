#include "../../include/models/GoToJailTile.hpp"
#include "../../include/core/GameEngine.hpp"
#include "../../include/core/TransactionLogger.hpp"
#include "../../include/models/JailTile.hpp"
#include "../../include/models/Player.hpp"

GoToJailTile::GoToJailTile(int index, JailTile& jailTile) : Tile(index, "PPJ", "Pergi ke Penjara"), jailTile(jailTile) {}

void GoToJailTile::onLand(Player& player, GameEngine& engine){
    jailTile.sendToJail(player);
    engine.getLogger().log(player.getUsername(),
                           "PPJ",
                           "Mendarat di PPJ dan dipindahkan ke penjara.");
}