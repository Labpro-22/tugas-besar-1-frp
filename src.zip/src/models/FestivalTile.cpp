#include "../../include/models/FestivalTile.hpp"
#include "../../include/core/GameEngine.hpp"
#include "../../include/core/EffectManager.hpp"
#include "../../include/core/TransactionLogger.hpp"
#include "../../include/models/GameContext.hpp"
#include "../../include/models/Player.hpp"
#include "../../include/models/Property.hpp"

#include <algorithm>

FestivalTile::FestivalTile(int index, const string& code) : Tile(index, code, "Festival"){}

void FestivalTile::onLand(Player& player, GameEngine& engine) {
    std::vector<Property*> candidates;
    for (Property* prop : player.getOwnedProperties()) {
        if (prop && !prop->isMortgaged()) {
            candidates.push_back(prop);
        }
    }

    if (candidates.empty()) {
        return;
    }

    GameContext ctx(engine.getPlayers(), &engine.getBoard(), engine.getDice().getTotal());
    auto bestIt = std::max_element(
        candidates.begin(),
        candidates.end(),
        [&](Property* lhs, Property* rhs) {
            return lhs->calculateRent(ctx) < rhs->calculateRent(ctx);
        });

    Property& chosen = **bestIt;
    const int oldRent = chosen.calculateRent(ctx);

    engine.getEffectManager().applyFestival(player, chosen);

    const int newRent = chosen.calculateRent(ctx);
    engine.getLogger().logFestival(player.getUsername(),
                                   chosen.getCode(),
                                   oldRent,
                                   newRent,
                                   chosen.getFestivalDuration());
}